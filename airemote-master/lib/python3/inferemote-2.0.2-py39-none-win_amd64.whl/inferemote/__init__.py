import os

__version__="2.0.2 (2023-03-22 23:10)"
__inferemote_dir__ = os.path.join(os.path.dirname(__file__), "")
__airlab_dir__ = os.path.join(os.path.dirname(__file__), "airlab/")

def version():
    print(__version__)

def dirs():
    return { "inferemote": __inferemote_dir__, "airlab": __airlab_dir__ }
