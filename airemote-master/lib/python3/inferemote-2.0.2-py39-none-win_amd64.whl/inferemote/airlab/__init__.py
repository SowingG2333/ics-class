from .googlenet.googlenet import GoogleNet # keep working with cc applet
from .lenet.lenet import LeNet
from .picasso.air import Picasso
from .yolov4.air import Yolov4
from .deeplabv3.air import Deeplabv3

import os, sys, importlib

def Load(**kwargs):
    try:
        name = kwargs['name']
        lib = importlib.import_module("inferemote.airlab.{}".format(name))
        #sys.path.append(os.getcwd())
        #lib = importlib.import_module(name)

        if not 'remote' in kwargs:
            kwargs['remote'] = 'localhost'
        return lib.Instance(**kwargs)

    except:
        return None
