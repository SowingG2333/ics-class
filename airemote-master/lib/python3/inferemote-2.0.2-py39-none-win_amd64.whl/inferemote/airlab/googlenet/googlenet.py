#!/usr/bin/env python3
"""
Inferemote: a Remote Inference Toolkit for Ascend 310
                <https://gitee.com/haojiash/airemote>
"""
import sys, os
import numpy as np
import cv2 as cv

from inferemote.atlas_remote import AtlasRemote
from .image_net_classes import get_image_net_class

class GoogleNet(AtlasRemote):
    MODEL_WIDTH  = 224
    MODEL_HEIGHT = 224

    def __init__(self, **kwargs):
        super().__init__(port=5530, **kwargs)
        self.verbose = False
        if 'verbose' in kwargs:
            self.verbose = kwargs['verbose']
    
    def pre_process(self, bgr_img):
        img = bgr_img
        img = cv.resize(img, (self.MODEL_WIDTH, self.MODEL_HEIGHT))
        blob = img.tobytes()
        return blob

    def post_process(self, result):
        blob = result[0]
        blob = np.frombuffer(blob, np.float32)
        blob = blob.reshape((1, 1000, 1, 1, ))

        vals = blob[0].flatten()
        top_k = vals.argsort()[-1:-6:-1]
        if self.verbose:
            print("======== top5 inference results: =============")
        for n in top_k:
            object_class = get_image_net_class(n)
            if self.verbose:
                print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))

        label = get_image_net_class(top_k[0])
        text = "{}label: {}, confidence: {:.4f}{}".format('{', label, vals[top_k[0]], '}')
        return text

''' Ends. '''
