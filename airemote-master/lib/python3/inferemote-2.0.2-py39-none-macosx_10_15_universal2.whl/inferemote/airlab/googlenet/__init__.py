
def Instance(**kwargs):
    if kwargs['remote'] == 'localhost':
        from .googlenet import GoogleNet
    else:
        from .air import GoogleNet

    return GoogleNet(**kwargs)
