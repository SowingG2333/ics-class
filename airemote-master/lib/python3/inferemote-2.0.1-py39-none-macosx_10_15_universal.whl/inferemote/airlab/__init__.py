from .googlenet.googlenet import GoogleNet # keep working with cc applet
from .lenet.lenet import LeNet
from .picasso.air import Picasso
from .yolov4.air import Yolov4
from .deeplabv3.air import Deeplabv3
