#!python
import argparse
from inferemote.remote_factory import RemoteFactory

def _parse_args():
        ap = argparse.ArgumentParser()
        ap.add_argument("-r", "--remote", #required=True,
            help="the remote model/applet url, such as 'tcp://192.168.1.123:5550'")
        args = vars(ap.parse_args())
        return args['remote']

if __name__ == '__main__':

    rmt = _parse_args()
    remote = RemoteFactory.create(rmt)
    print("REMOTE ({}):\n{}".format(rmt, remote.get_info()))
