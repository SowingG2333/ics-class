# -*- coding: utf-8 -*-
import getpass

# pip install uvicorn prometheus_client 
# pip install fastapi yaml
# uvicorn main:app --reload
 
from fastapi import FastAPI
from fastapi.responses import PlainTextResponse,HTMLResponse

app = FastAPI()

import os, sys, uvicorn, json, argparse
from inferemote import __airlab_dir__

parser = argparse.ArgumentParser()
parser.add_argument('-d', '--dir', default=__airlab_dir__, help=f"directory for airlab files, default is ``{__airlab_dir__}''")
parser.add_argument('-p', '--port', type=int, nargs='?', default=80, help="set to start web on port, default port is 80")
args, _ = parser.parse_known_args()

from inferemote.service import AirlabService
airlab = AirlabService(args.dir)
port = args.port

import inferemote.airlab_html as AirlabHtml
html_header = """
    <html><head><style>
h1 {text-align:center}
h2 {text-align:left}
h3 {text-align:right}
li {
    text-align: left;
    font-size: 18px;
    line-height: 25px;
    text-indent: 2em;
    margin: 0 auto;
    margin-top: 10px;
    color: #6699FF;
}
p{
    text-align: left;
    font-size: 18px;
    line-height: 25px;
    margin: 0 auto;
    text-indent: 5em;
    margin: 0 auto;
}
</style></head><body>
    <h1> Airlab Services for Atlas 200 DK </h1>
    <p style="text-align:center"><a target="_blank" href="https://gitee.com/haojiash/airemote"> https://gitee.com/haojiash/airemote </a></p> <hr />
"""
html_footer = f"<hr/><p style='text-align:right'> These services are started by user: {getpass.getuser()}</body></html>"

@app.get('/', response_class=HTMLResponse)
async def index():
    html = html_header + "<h2> Airlab services running </h2>"
    html += AirlabHtml.listall_in_html(airlab)
    return html + html_footer

@app.get("/model/{name}", response_class=HTMLResponse)
async def model(name:str):
   html = html_header + f"<h2> Documents for {name} </h2>"
   html += AirlabHtml.modelinfo_in_html(airlab, name)
   return html + html_footer

def start():
  print(f"\nStarting airweb for path: ``{args.dir}'' on port ``{args.port}''\n")
  uvicorn.run(app="web_app:app", host="0.0.0.0", port=port)#, reload=True)

if __name__ == "__main__":
  start()
