
def Instance(**kwargs):
    if kwargs['remote'] == 'localhost':
        from .picasso import Picasso
    else:
        from .air import Picasso

    return Picasso(**kwargs)
